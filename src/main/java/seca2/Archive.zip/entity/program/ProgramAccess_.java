/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package seca2.entity.program;

import EDS.Entity.EnterpriseRelationship_;
import javax.persistence.metamodel.StaticMetamodel;

/**
 *
 * @author KH
 */
@StaticMetamodel(ProgramAccess.class)
public class ProgramAccess_ extends EnterpriseRelationship_ {
    
}
