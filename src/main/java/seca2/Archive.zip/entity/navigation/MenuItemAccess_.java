/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package seca2.entity.navigation;

import EDS.Entity.EnterpriseRelationship_;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

/**
 *
 * @author KH
 */
@StaticMetamodel(MenuItem.class)
public class MenuItemAccess_ extends EnterpriseRelationship_ {
    
}
