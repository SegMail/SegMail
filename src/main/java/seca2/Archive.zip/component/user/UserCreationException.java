/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seca2.component.user;

/**
 *
 * @author LeeKiatHaw
 */
public class UserCreationException extends Exception{

    public UserCreationException(String message) {
        super(message);
    }
    
}
