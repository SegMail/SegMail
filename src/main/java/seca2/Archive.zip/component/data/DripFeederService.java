/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package seca2.component.data;

/**
 *
 * @author vincent.a.lee
 * @param <T>
 */
public class DripFeederService<T extends Object> {
    
    private DripDatasource<T> datasource;
    private int pourSize;
    private int dripSize;
    
    
}
