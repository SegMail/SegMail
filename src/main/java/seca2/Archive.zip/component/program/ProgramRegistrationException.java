/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seca2.component.program;

/**
 *
 * @author LeeKiatHaw
 */
public class ProgramRegistrationException extends Exception {

    public ProgramRegistrationException(String message) {
        super(message);
    }
    
}
